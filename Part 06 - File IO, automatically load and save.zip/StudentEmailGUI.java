/*
      Author: Moose OMalley
 Source File: StudentEmailGUI.java
 Description: Part of the "Java - LinkedLists - Students GUI - Add, Delete, Display"
              video tutorials.  The latest source code.

The Students GUI Linked List tutorial series:
* Java - LinkedLists - Students GUI - Add, Delete, Display - Part 01
https://youtu.be/0KdG9DZgi6I
* Java - LinkedLists - Students GUI - Add, Delete, Display - Part 02 - Edit
https://youtu.be/LXMg1E6gJJ0
* Java - LinkedLists - Students GUI - Add, Delete, Display - Part 03 - NetBeans
https://youtu.be/xrNSa0nXDLE

Java Source code is in my GitHub:
* https://github.com/MooseValley/LinkedLists-Students-GUI-Add-Delete-Display

See my other Java videos:
* Mike's Java Software Development Tutorial Videos:
http://tinyurl.com/MikesJavaVideos

*/

import javax.swing.*;
import java.awt.*;
import java.util.LinkedList;
import java.awt.event.*;

public class StudentEmailGUI extends JFrame
{
   // Constants:

   // GUI Componet:
   JTextArea  studentTextArea   = new JTextArea ();

   JLabel     idLabel           = new JLabel     ("ID: ");
   JTextField idTextField       = new JTextField (10);
   JLabel     nameLabel         = new JLabel     ("Name: ");
   JTextField nameTextField     = new JTextField (10);

   JButton    testDataButton    = new JButton ("Test Data");
   JButton    addButton         = new JButton ("Add");
   JButton    deleteButton      = new JButton ("Delete");
   JButton    editButton        = new JButton ("Edit");
   JButton    editSaveButton    = new JButton ("Save");
   JButton    displayAllButton  = new JButton ("Display All");
   JButton    exitButton        = new JButton ("Exit");




   public StudentEmailGUI ()
   {
      JPanel flow1Panel = new JPanel (new FlowLayout (FlowLayout.CENTER));
      JPanel flow2Panel = new JPanel (new FlowLayout (FlowLayout.CENTER));
      JPanel gridPanel  = new JPanel (new GridLayout (2, 1));

      Controller.setParent (StudentEmailGUI.this);

      studentTextArea.setEditable (false);

      flow1Panel.add (idLabel);
      flow1Panel.add (idTextField);
      flow1Panel.add (nameLabel);
      flow1Panel.add (nameTextField);

      flow2Panel.add (testDataButton);
      flow2Panel.add (addButton);
      flow2Panel.add (editButton);
      flow2Panel.add (editSaveButton);
      flow2Panel.add (deleteButton);
      flow2Panel.add (displayAllButton);
      flow2Panel.add (exitButton);

      gridPanel.add (flow1Panel);
      gridPanel.add (flow2Panel);

      editSaveButton.setEnabled (false);

      add (studentTextArea, BorderLayout.CENTER);
      add (gridPanel,       BorderLayout.SOUTH);


      addButton.addActionListener        (event -> addStudent ());
      displayAllButton.addActionListener (event -> displayAll ());
      editButton.addActionListener       (event -> editStudent ());
      editSaveButton.addActionListener   (event -> editSaveStudent ());
      exitButton.addActionListener       (event -> exitApplication ());
      deleteButton.addActionListener     (event -> deleteStudent ());
      testDataButton.addActionListener   (event -> addTestData ());

      //loadDataButton.addActionListener   (event -> Controller.fileLoad() );

      setTitle ("Student Linked List - v0.06");

      // Setup my own "Window Closing" method that runs when the user
      // clicks the "X" icon.  e.g. prompt user to confirm they want to exit,
      // or prompt user to see if they want to save data, etc.
      addWindowListener (new WindowAdapter()
      {
         public void windowClosing (WindowEvent e)
         {
            exitApplication ();
         }
      });

      Controller.fileLoad();
      displayAll ();
   }


   private void addStudent ()
   {
      boolean result = Controller.addStudent (idTextField.getText(), nameTextField.getText() );

      if (result == true)
      {
         displayAll ();

         nameTextField.setText("");
         idTextField.setText("");
      }
   }

   private void deleteStudent ()
   {
      boolean result = Controller.deleteStudent (idTextField.getText() );

      if (result == true)
      {
         displayAll ();

         nameTextField.setText("");
         idTextField.setText("");
      }
   }

   private void editStudent ()
   {
      boolean result = Controller.editStudent (idTextField.getText() );

      if (result == true)
      {
         editSaveButton.setEnabled   (true);

         editButton.setEnabled       (false);
         testDataButton.setEnabled   (false);
         addButton.setEnabled        (false);
         deleteButton.setEnabled     (false);
         displayAllButton.setEnabled (false);
         exitButton.setEnabled       (false);

         //nameTextField.setText (studentLinkedList.get (editIndex).getName () );
         nameTextField.setText (Controller.getEditedStudentName ()  );

         //idTextField.setText   (studentLinkedList.get (editIndex).getId () );
      }
   }

   private void editSaveStudent ()
   {
      // This code will preserve the changes the user made to the student
      // they were editing - and save them back into the Linked List.

      //studentLinkedList.get (editIndex).setName (nameTextField.getText() );
      //studentLinkedList.get (editIndex).setId   (idTextField.getText() );

      Controller.setEditedStudentIdAndName  (idTextField.getText(),
                                             nameTextField.getText() );


      displayAll ();

      nameTextField.setText ("");
      idTextField.setText   ("");

      editSaveButton.setEnabled   (false);

      editButton.setEnabled       (true);
      testDataButton.setEnabled   (true);
      addButton.setEnabled        (true);
      deleteButton.setEnabled     (true);
      displayAllButton.setEnabled (true);
      exitButton.setEnabled       (true);
   }

   private void addTestData ()
   {
      nameTextField.setText ("Moose");
      idTextField.setText   ("s123");
      addStudent ();

      nameTextField.setText ("Frankie");
      idTextField.setText   ("s111");
      addStudent ();

      nameTextField.setText ("Bella");
      idTextField.setText   ("s789");
      addStudent ();
   }

   private void displayAll ()
   {
      studentTextArea.setText (Controller.asString() );
   }

   private void exitApplication ()
   {
      Controller.fileSave();

      System.exit (0); // All is OK.
   }

   public static void main (String[] args)
   {
      StudentEmailGUI app = new StudentEmailGUI ();
      app.setVisible  (true);
      app.setSize     (500, 310);
      app.setLocation (200, 100);
      app.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
   }
} // public class StudentEmailGUI