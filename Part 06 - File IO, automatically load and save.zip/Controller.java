import java.util.LinkedList;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import java.util.Formatter;
import java.util.Scanner;
import java.io.FileReader;
import java.io.FileNotFoundException;
import java.util.NoSuchElementException;
import java.util.FormatterClosedException;


public class Controller
{
   private static final String DATA_FILE_NAME = "student.txt";

   // Class Instance Data:
   private static LinkedList<StudentEmail> studentLinkedList = new LinkedList<StudentEmail> ();
   private static int editIndex;
   private static JFrame parentJFrame;


   public static void setParent (JFrame parent)
   {
      parentJFrame = parent;
   }

   private static boolean isStudentIdInLinkedList (String idStr)
   {
      boolean inList = false;

      for (StudentEmail stud : studentLinkedList)
      {
         if (stud.getId ().compareToIgnoreCase (idStr) == 0)
         {
            inList = true;
         }
      }

      return inList;
   }


   public static boolean addStudent (String idStr, String nameStr)
   {
      boolean result = false; // Student not added.

      if (isStudentIdInLinkedList (idStr) == true)
      {
         JOptionPane.showMessageDialog (parentJFrame,
                              "Error: student ID is already in the database.");
      }
      else
      {
         try
         {
            StudentEmail stud = new StudentEmail (nameStr,
                                                  idStr);

            result = true; // Add successful. :)
            studentLinkedList.add (stud);
         }
         catch (StudentEmailException error)
         {
            JOptionPane.showMessageDialog (parentJFrame, error.toString ());
            // myLabel.setText (error.toString ());
         }
      }

      return result;
   }

   public static boolean deleteStudent (String idStr)
   {
      boolean result = false; // e.g. Student does note exist.

      if (studentLinkedList.size() == 0)
      {
         JOptionPane.showMessageDialog (parentJFrame,
                                        "Error: Database is empty.");
      }
      else if (isStudentIdInLinkedList (idStr) == false)
      {
         JOptionPane.showMessageDialog (parentJFrame,
                                       "Error: student ID is not in the database.");
      }
      else
      {
         for (int s = 0; s < studentLinkedList.size(); s++)
         {
            String currId = studentLinkedList.get (s).getId ();

            if (currId.compareToIgnoreCase (idStr) == 0)
            {
               studentLinkedList.remove (s);
               result = true;                // Student deleted.
               s = studentLinkedList.size(); // Exit Loop!
            }
         }
      }

      return result;
   }

   public static boolean editStudent (String idStr)
   {
      boolean result = false; // e.g. Student does note exist.

      editIndex = -1;

      if (studentLinkedList.size() == 0)
      {
         JOptionPane.showMessageDialog (parentJFrame,
                                        "Error: Database is empty.");
      }
      else if (isStudentIdInLinkedList (idStr) == false)
      {
         JOptionPane.showMessageDialog (parentJFrame,
                                        "Error: student ID is not in the database.");
      }
      else
      {
         editIndex = -1;

         for (int s = 0; s < studentLinkedList.size(); s++)
         {
            String currId = studentLinkedList.get (s).getId ();

            if (currId.compareToIgnoreCase (idStr) == 0)
            {
               editIndex = s;
               result = true;                // Student found.
               s = studentLinkedList.size(); // Exit Loop
            }
         }
      }

      return result;
   }

   public static String getEditedStudentName ()
   {
      if (editIndex >= 0)
      {
         return studentLinkedList.get (editIndex).getName ();
      }
      else
      {
         return "";
      }
   }

   public static void setEditedStudentIdAndName (String idStr, String nameStr)
   {
      if (editIndex >= 0)
      {
         studentLinkedList.get (editIndex).setName (nameStr );
         studentLinkedList.get (editIndex).setId   (idStr );
      }
   }


   public static String asString()
   {
      String outStr = "";

      for (StudentEmail stud : studentLinkedList)
      {
         outStr = outStr + stud.toString() + "\n";
      }

      return outStr;
   }

   public static void fileLoad()
   {
      studentLinkedList = new LinkedList<StudentEmail> ();

      try
      {
         Scanner inFile = new Scanner (new FileReader (DATA_FILE_NAME) );

         while (inFile.hasNext() == true)
         {
            String nameStr = inFile.nextLine();
            String idStr   = inFile.nextLine();

            StudentEmail stud = new StudentEmail (nameStr, idStr);

            studentLinkedList.add (stud);
         }

         inFile.close();
      }
      catch (FileNotFoundException | NoSuchElementException | StudentEmailException err)
      {
         err.printStackTrace();

         //System.exit (-1); // ERROR
      }
   }

   public static void fileSave()
   {
      try
      {
         Formatter outFile = new Formatter (DATA_FILE_NAME);

         for (StudentEmail stud : studentLinkedList)
         {
            outFile.format ("%s", stud.getName () + "\n");
            outFile.format ("%s", stud.getId ()   + "\n");
         }

         outFile.close();
      }
      catch (FileNotFoundException | NoSuchElementException | FormatterClosedException err)
      {
         err.printStackTrace();

         //System.exit (-1); // ERROR
      }
   }


} // public class Controller
